// Task 1: Write a program that prints the following text.
// Textline with " in it
//          Tabbed textline with \n in it

#include <iostream>

using namespace std;

int main()
{
    cout << "Textline with \"\ in it  " << endl;
    cout << "\t Tabbed textline with \\n\ in it ";

    return 0;
}